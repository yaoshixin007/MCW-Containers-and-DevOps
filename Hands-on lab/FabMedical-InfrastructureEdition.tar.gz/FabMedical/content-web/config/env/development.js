'use strict';

module.exports = {
	appInsightKey: '[YOUR APPINSIGHTS KEY]'
};
